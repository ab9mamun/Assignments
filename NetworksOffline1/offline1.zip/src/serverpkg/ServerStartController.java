package serverpkg;

public class ServerStartController {
    private ServerMain main;


    public void setMain(ServerMain main) {
        this.main = main;
    }
}
